//
//  BRCityPickerViewCtl.m
//  EPJH
//
//  Created by Hans on 2020/12/10.
//

#import "BRCityPickerViewCtl.h"
#import "EPProvinceCityModel.h"

@interface BRCityPickerViewCtl ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, copy) NSString * keyStr;
@property (nonatomic, assign) EPAddressSxType addressType;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *tableItems;
@end

@implementation BRCityPickerViewCtl

- (instancetype)initWithAddressVCType:(EPAddressSxType)addressType key:(NSString *)keyStr{
    
    if (self = [super init]) {
        self.addressType = addressType;
        if (keyStr.length > 0) { self.navigationItem.title = keyStr; self.keyStr = keyStr; }
        [self getLocalData];
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"所在地";
    
    [self.view addSubview:self.tableView];

    // 当界面是省份的时候，返回按钮需要做校验，返回空值回去。方便处理、
    if (self.addressType == EPAddressSxTypeProvince) {
        self.navigationItem.leftBarButtonItem = [UIBarButtonItem app_crateNavigationBarItemImageNamed:@"ic_common_arrow_back_black" highImageNamed:nil size:CGSizeMake(50, 50) target:self action:@selector(navBackAction)];
    }
}

- (void)navBackAction{
    
    if (self.addressCompleted) {
        NSString *province = @"";
        NSString *city = @"";
        self.addressCompleted(NO,province, city);
        
        NSArray *vcs = self.navigationController.childViewControllers;
        [self.navigationController popToViewController:vcs[vcs.count - 2] animated:YES];
    }
}

- (void)getLocalData{
    
    self.tableItems = [NSMutableArray arrayWithCapacity:10];

    switch (self.addressType) {
            
        case EPAddressSxTypeProvince:{

            [self.tableItems addObjectsFromArray:[LocalDataHandler getProvinceCityDataSource]];
            [self.tableView reloadData];
        }
            break;
            
        case EPAddressSxTypeCity:{
            
            
            NSArray * listArr = [[NSArray alloc] init];
            listArr = [LocalDataHandler getProvinceCityDataSource];

            for (int i = 0; i < listArr.count ; i ++) {
                EPProvinceCityModel * model = listArr[i];
                NSString * idStr = model.name;
                NSArray *resultList = model.city;
                if ([idStr isEqualToString:self.keyStr]) {
                    [self.tableItems addObjectsFromArray:resultList];
                    [self.tableView reloadData];
                }
            }
        }
            break;
            
        default:
            break;
    }
     
}

#pragma mark - Table view data source

- (UITableView *)tableView {
    
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, APP_WIDTH, APP_HEIGHT - 92 )];
        _tableView.delegate = self;
        _tableView.dataSource  = self;
        _tableView.rowHeight = 60;
        _tableView.tableFooterView = [[UIView alloc]init];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"BRCityPickerViewCell"];
    }
    return _tableView;
}
 
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.tableItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
     
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BRCityPickerViewCell"];
    cell.accessoryType =  UITableViewCellAccessoryDisclosureIndicator;

    switch (self.addressType) {
            
        case EPAddressSxTypeProvince:{

            EPProvinceCityModel * model = self.tableItems[indexPath.row];
            cell.textLabel.text = model.name;
        }
            break;
            
        case EPAddressSxTypeCity:{
            
            NSDictionary *dicT = self.tableItems[indexPath.row];
            cell.textLabel.text = dicT[@"name"];
        }
            break;
            
        default:
            break;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WS(weakSelf);

    switch (self.addressType) {
            
        case EPAddressSxTypeProvince:{

            EPProvinceCityModel * model = self.tableItems[indexPath.row];
            BRCityPickerViewCtl *Vc = [[BRCityPickerViewCtl alloc] initWithAddressVCType:EPAddressSxTypeCity key:model.name];
            [self.navigationController pushViewController:Vc animated:YES];
            [Vc setAddressCompleted:^(BOOL isSucess, NSString * _Nonnull province, NSString * _Nonnull city) {
                if (weakSelf.addressCompleted) {
                    weakSelf.addressCompleted(YES,province, city);
                    NSArray *vcs = self.navigationController.childViewControllers;
                    [weakSelf.navigationController popToViewController:vcs[vcs.count - 3] animated:YES];
                }
            }];
        }
            break;
            
        case EPAddressSxTypeCity:{
            
            NSDictionary *dicT = self.tableItems[indexPath.row];
            if (self.addressCompleted) {
                self.addressCompleted(YES,self.keyStr, dicT[@"name"]);
            }
        }
            break;
            
        default:
            break;
    }

}

@end
