//
//  BRCityPickerViewCtl.h
//  EPJH
//
//  Created by Hans on 2020/12/10.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, EPAddressSxType) {
    EPAddressSxTypeProvince = 0,
    EPAddressSxTypeCity,
};

NS_ASSUME_NONNULL_BEGIN

@interface BRCityPickerViewCtl : RootViewCtl

- (instancetype)initWithAddressVCType:(EPAddressSxType)addressType  key:(NSString *)keyStr;

@property (nonatomic, copy) void(^addressCompleted)(BOOL isSucess,NSString *province, NSString *city);

@end

NS_ASSUME_NONNULL_END
