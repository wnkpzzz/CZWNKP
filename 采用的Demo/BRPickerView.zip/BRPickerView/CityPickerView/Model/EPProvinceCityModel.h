//
//  EPProvinceCityModel.h
//  EPJH
//
//  Created by Hans on 2020/12/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EPProvinceCityModel : NSObject

@property (nonatomic,copy) NSString * name;
@property (nonatomic,strong) NSArray * city;
@property (nonatomic,strong) NSArray * area;

@end

NS_ASSUME_NONNULL_END
