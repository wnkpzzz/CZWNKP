//
//  BRProPickerView.m
//  EPJH
//
//  Created by Hans on 2020/12/10.
//

#import "BRProPickerView.h"

@interface BRProPickerView()<UIPickerViewDataSource, UIPickerViewDelegate>

@property (nonatomic,strong) UIPickerView *pickerView; //选择器
@property (nonatomic,copy) BRProPickerResultBlock resultBlock;   // 选中后的回调
@property (nonatomic,copy) BRProPickerCancelBlock cancelBlock;   // 取消选择的回调
 
@property (strong,nonatomic) NSArray *provinceList;//省的数组
@property (strong,nonatomic) NSArray *cityList;//市的数组
@property (strong,nonatomic) NSMutableArray *areaList;//县和区的数组

@property (assign,nonatomic) NSInteger selectOneRow;//记录第一级选中的下标
@property (assign,nonatomic) NSInteger selectTwoRow;//记录第二级选中的下标
@property (assign,nonatomic) NSInteger selectThreeRow;//记录第三级选中的下标

@end

@implementation BRProPickerView

+ (void)showProPickerWithResultBlock:(BRProPickerResultBlock)resultBlock
                         cancelBlock:(BRProPickerCancelBlock)cancelBlock{
    BRProPickerView * filterView = [[BRProPickerView alloc] initWithResultBlock:resultBlock cancelBlock:cancelBlock];
    [filterView showWithAnimation:YES];
}

#pragma mark - 初始化选择器

- (instancetype)initWithResultBlock:(BRProPickerResultBlock)resultBlock
                          cancelBlock:(BRProPickerCancelBlock)cancelBlock{
    if (self = [super init]) {
  
        self.resultBlock = resultBlock;
        self.cancelBlock = cancelBlock;
        
        if (cancelBlock) {  [self initUIIsClear:YES]; }else { [self initUIIsClear:NO]; }
    }
    return self;
}

//初始化子
- (void)initUIIsClear:(BOOL)isClear {
    [super initUIIsClear:isClear];
    
    // 添加时间选择器
    [self.alertView addSubview:self.pickerView];
    [self.alertView sendSubviewToBack:self.pickerView];
    
    [self Dataparsing];//解析json数据，获得省的数据
    [self getCitydate:0];//获得默认市的数据
    [self getAreaDate:0];//获得默认县区的数据
    [self.pickerView reloadAllComponents];

}

//弹出视图
- (void)showWithAnimation:(BOOL)animation {
    
    // 1.获取当前应用的主窗口
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    [keyWindow addSubview:self];
    if (animation) {
        // 动画前初始位置
        CGRect rect = self.alertView.frame;
        rect.origin.y = APP_HEIGHT;
        self.alertView.frame = rect;
        
        // 浮现动画
        [UIView animateWithDuration:0.3 animations:^{
            CGRect rect = self.alertView.frame;
            rect.origin.y -= kDatePicHeight + kTopViewHeight + kBottomViewHeight;
            self.alertView.frame = rect;
        }];
    }
}

//关闭视图方法
- (void)dismissWithAnimation:(BOOL)animation {
    // 关闭动画
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = self.alertView.frame;
        rect.origin.y += kDatePicHeight + kTopViewHeight + kBottomViewHeight;
        self.alertView.frame = rect;
        self.backgroundView.alpha = 0;
    } completion:^(BOOL finished) {
        [self.leftBtn removeFromSuperview];
        [self.rightBtn removeFromSuperview];
        [self.titleLabel removeFromSuperview];
        [self.lineView removeFromSuperview];
        [self.topView removeFromSuperview];
        [self.pickerView removeFromSuperview];
        [self.alertView removeFromSuperview];
        [self.backgroundView removeFromSuperview];
        [self removeFromSuperview];
        
        self.leftBtn = nil;
        self.rightBtn = nil;
        self.titleLabel = nil;
        self.lineView = nil;
        self.topView = nil;
        self.pickerView = nil;
        self.alertView = nil;
        self.backgroundView = nil;
    }];
}

#pragma mark - 点击事件

//确定按钮的点击事件
- (void)clickBottomBtn {
    [self clickRightBtn];
}
- (void)clickRightBtn {
    
    [self dismissWithAnimation:YES];
    
    // 点击确定按钮后，执行回调
    if(self.resultBlock) {
        
        NSString * oneKey = @"";
        NSString * twoKey = @"";
        NSString * threeKey = @"";

        YPProjectSxModel * oneModel = self.provinceList[self.selectOneRow];
        YPProjectSxModel * twoModel = self.cityList[self.selectTwoRow];
        NSDictionary *dic = self.areaList[self.selectThreeRow];
        oneKey = oneModel.part;
        twoKey = twoModel.part;
        threeKey = dic[@"name"];
  
        self.resultBlock(oneKey, twoKey, threeKey);
    }
}

//取消按钮的点击事件
- (void)clickLeftBtn {
    [self dismissWithAnimation:YES];
    if (self.cancelBlock) {
        self.cancelBlock();
    }
}
- (void)clearBtnClick {
    [self dismissWithAnimation:YES];
    if (_cancelBlock) {
        _cancelBlock();
    }
}

//背景视图的点击事件
- (void)didTapBackgroundView:(UITapGestureRecognizer *)sender {
    [self dismissWithAnimation:NO];
    if (self.cancelBlock) {
        self.cancelBlock();
    }
}

#pragma mark - 懒加载

- (UIPickerView *)pickerView {
    if (!_pickerView) {
        _pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, kTopViewHeight + 0.5, APP_WIDTH, kDatePicHeight)];
        _pickerView.backgroundColor = [UIColor whiteColor];
        _pickerView.dataSource = self;
        _pickerView.delegate = self;
        _pickerView.showsSelectionIndicator = YES;
    }
    return _pickerView;
}

//解析json数据,获取省的数据
- (void)Dataparsing{
    self.provinceList = [[NSArray alloc]init];
    self.provinceList = [LocalDataHandler getCateDataSource];

}

//取到市的数据，默认第0行
- (void)getCitydate:(NSInteger)row{
    self.cityList=[[NSArray alloc]init];
    NSArray *cityList = [LocalDataHandler getSubCateDataSource];
    if (cityList.count >= row) {
        self.cityList = cityList;
    }
}

//取到县区的数据，默认第0行
- (void)getAreaDate:(NSInteger)row{
    self.areaList =  [NSMutableArray arrayWithCapacity:10];
    if (self.cityList.count >= row) {
        YPProjectSxModel * model = self.cityList[row];
        [self.areaList addObjectsFromArray:model.project];
    }
}

#pragma mark pickerView代理方法
//返回列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 3;
}

//返回每列行数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (component == 0) {//省的行数
        return self.provinceList.count;
    }
    else if (component == 1){//市的行数
        return self.cityList.count;
    }
    else{//县区的行数
        return self.areaList.count;
    }
    return 0;
}

//返回行高
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 25;
}

//返回每列每行的内容
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view {

    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, (APP_WIDTH) / 3, 37 * kScaleFit)];
    bgView.backgroundColor = [UIColor clearColor];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(5 * kScaleFit, 0, (APP_WIDTH) / 3 - 10 * kScaleFit, 37 * kScaleFit)];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont systemFontOfSize:16.0f * kScaleFit];
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.5f;
    [bgView addSubview:label];
 
    if (component == 0) {
        YPProjectSxModel * model = self.provinceList[row];
        label.text = model.part;
    }
    else if (component == 1){
        YPProjectSxModel * model = self.cityList[row];
        label.text = model.part;
    }
    else if (component == 2){ 
        NSDictionary *dic = self.areaList[row];
        label.text = dic[@"name"];
    }
    return bgView;
}

//当选中每列每行的事件
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    //注意此处一定要用static
    static NSInteger oneRow = 0;
    static NSInteger twoRow = 0;
    static NSInteger threeRow = 0;
    
    //省的那一列
    if (component == 0) {
        
        self.selectOneRow = row;
 
        // 三级联动所需，现在仅需二三级关联。
//        [self getCitydate:row];//取到对应的市的数据
//        [pickerView reloadComponent:1];//重新加载 第二列
//        [pickerView selectRow:0 inComponent:1 animated:YES];//默认选中第二列中的第一个数据
//
//        [self getAreaDate:0];//取到对应的县区的数据
//        [pickerView reloadComponent:2];//重新加载第三列
//        [pickerView selectRow:0 inComponent:2 animated:YES];//默认选中第三列中的第一个数据
 
        oneRow = row;
        twoRow = 0;
        threeRow = 0;
    }
    
    //市的那一列
    if (component == 1){
        self.selectTwoRow = row;
        [self getAreaDate:row];//取到对应的县区的数据
        [pickerView reloadComponent:2];//重新加载第三列
        [pickerView selectRow:0 inComponent:2 animated:YES];//默认选中第三列中的第一个数据
        
        twoRow = row;
        threeRow = 0;
    }
    
    //县区的那一列
    if (component == 2){
        self.selectThreeRow = row;
        threeRow = row; 
    }
}
 
@end
