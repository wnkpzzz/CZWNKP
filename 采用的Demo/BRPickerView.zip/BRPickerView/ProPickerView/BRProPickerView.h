//
//  BRProPickerView.h
//  EPJH
//
//  Created by Hans on 2020/12/10.
//

#import <UIKit/UIKit.h>
#import "BRBaseView.h"
#import "YPProjectSxModel.h"

typedef void(^BRProPickerResultBlock)(NSString * _Nullable nodeKey,NSString * _Nullable posKey,NSString * _Nullable proKey);
typedef void(^BRProPickerCancelBlock)(void);

NS_ASSUME_NONNULL_BEGIN

@interface BRProPickerView : BRBaseView

+ (void)showProPickerWithResultBlock:(BRProPickerResultBlock)resultBlock
                     cancelBlock:(BRProPickerCancelBlock)cancelBlock;


@end

NS_ASSUME_NONNULL_END


